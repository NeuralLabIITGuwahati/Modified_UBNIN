clc
clear
close

%% Load files

nHC = 70; % Number of healthy
nPD = 179; % Number of PD
ind_assoc_PD = ind_cor;
ind_assoc_HC = ind_cor_HC;

%% Individual UBNIN

for i = 1:size(ind_assoc_HC,1)
    A = squeeze(ind_assoc_HC(i,:,:));
    Adj_I = TS_Func_Adjacency(A,30);
    Ind_Adj_HC(i,:,:) = Adj_I;
    for j = 1:56
        deg_HC(i,j) = nnz(Adj_I(:,j));
    end
    [val(i,:),node_max_deg_HC(i,:)] = max(deg_HC(i,:));
end
node_majority_max_deg_HC = mode(node_max_deg_HC); % node with highest degree as per majority 
% 9th node is L.middle.orbitofrontal.gyrus
[cnt_unique, unique_a] = hist(node_max_deg_HC,unique(node_max_deg_HC))
%%

for i = 1:size(ind_assoc_PD,1)
    A = squeeze(ind_assoc_PD(i,:,:));
    Adj_I = TS_Func_Adjacency(A,30);
    Ind_Adj_PD(i,:,:) = Adj_I;
    for j = 1:56
        deg_PD(i,j) = nnz(Adj_I(:,j));
    end
    [val(i,:),node_max_deg_PD(i,:)] = max(deg_PD(i,:));
end
node_majority_max_deg_PD = mode(node_max_deg_PD); % node with highest degree as per majority 
% 9th node is L.middle.orbitofrontal.gyrus
[cnt_unique, unique_a] = hist(node_max_deg_PD,unique(node_max_deg_PD))


%% UBNIN for individual

digits(1000);

for l = 1:nHC
    Input_HC = squeeze(Ind_Adj_HC(l,:,:));
    [~, ~, UBNIN_HC] = TS_Func_UBNIN_Modified(Input_HC,node_majority_max_deg_HC);
    UBNIN_HC_all(l,:) = vpa(UBNIN_HC);
end

for i = 1:nPD
    Input_PD = squeeze(Ind_Adj_PD(i,:,:));
    [~, ~, UBNIN_PD] = TS_Func_UBNIN_Modified(Input_PD,node_majority_max_deg_PD);
    UBNIN_PD_all(i,:) = vpa(UBNIN_PD);
end